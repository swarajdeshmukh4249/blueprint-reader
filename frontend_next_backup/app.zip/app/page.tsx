"use client";

import Link from "next/link";
import { useUser } from "@clerk/nextjs";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export default function LandingPage() {
  const { isSignedIn, isLoaded } = useUser();
  const router = useRouter();

  useEffect(() => {
    if (isLoaded && isSignedIn) router.push("/auth-redirect");
  }, [isLoaded, isSignedIn, router]);

  return (
    <main className="min-h-screen grid-bg relative overflow-hidden" style={{ background: 'var(--bg-base)' }}>

      {/* Ambient glow top */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] rounded-full opacity-20 blur-[120px] pointer-events-none"
        style={{ background: 'radial-gradient(ellipse, #00D4FF 0%, transparent 70%)' }} />

      {/* Scan line animation */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-5">
        <div className="absolute w-full h-px bg-gradient-to-r from-transparent via-cyan-400 to-transparent"
          style={{ animation: 'scan 8s linear infinite' }} />
      </div>

      {/* Nav */}
      <nav className="relative z-10 flex items-center justify-between px-8 py-6 max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold"
            style={{ background: 'var(--accent)', color: 'var(--bg-base)' }}>B</div>
          <span className="font-bold text-lg tracking-tight" style={{ fontFamily: 'var(--font-display)', color: 'var(--text-primary)' }}>
            Blueprint<span style={{ color: 'var(--accent)' }}>AI</span>
          </span>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/sign-in"
            className="text-sm font-medium transition-colors px-4 py-2 rounded-lg"
            style={{ color: 'var(--text-secondary)' }}
            onMouseEnter={e => (e.currentTarget.style.color = 'var(--text-primary)')}
            onMouseLeave={e => (e.currentTarget.style.color = 'var(--text-secondary)')}>
            Sign in
          </Link>
          <Link href="/sign-up"
            className="text-sm font-semibold px-5 py-2.5 rounded-xl transition-all"
            style={{ background: 'var(--accent)', color: 'var(--bg-base)' }}
            onMouseEnter={e => (e.currentTarget.style.opacity = '0.85')}
            onMouseLeave={e => (e.currentTarget.style.opacity = '1')}>
            Get started
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative z-10 max-w-7xl mx-auto px-8 pt-20 pb-32 text-center">

        {/* Badge */}
        <div className="animate-fade-up inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-mono mb-8 border"
          style={{ borderColor: 'var(--border-bright)', background: 'var(--bg-elevated)', color: 'var(--accent)' }}>
          <span className="w-1.5 h-1.5 rounded-full inline-block" style={{ background: 'var(--green)', animation: 'blink 2s infinite' }} />
          AI-Powered BOQ Generation · Now in Beta
        </div>

        <h1 className="animate-fade-up-1 text-6xl md:text-8xl font-black leading-none tracking-tight mb-6"
          style={{ fontFamily: 'var(--font-display)', color: 'var(--text-primary)' }}>
          Read Blueprints.<br />
          <span className="glow-text" style={{ color: 'var(--accent)' }}>Generate BOQ.</span><br />
          Instantly.
        </h1>

        <p className="animate-fade-up-2 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed"
          style={{ color: 'var(--text-secondary)' }}>
          Upload architectural blueprints — PDF, DXF, DWG, or image —
          and get accurate room detection, area calculations, and
          construction cost estimates in seconds.
        </p>

        <div className="animate-fade-up-3 flex flex-col sm:flex-row gap-4 justify-center mb-20">
          <Link href="/sign-up"
            className="group inline-flex items-center gap-2 px-8 py-4 rounded-2xl font-semibold text-base transition-all glow-accent"
            style={{ background: 'var(--accent)', color: 'var(--bg-base)' }}>
            Start for free
            <span className="transition-transform group-hover:translate-x-1">→</span>
          </Link>
          <Link href="/sign-in"
            className="inline-flex items-center gap-2 px-8 py-4 rounded-2xl font-semibold text-base border transition-all"
            style={{ borderColor: 'var(--border-bright)', color: 'var(--text-primary)', background: 'var(--bg-elevated)' }}>
            View demo
          </Link>
        </div>

        {/* Stats row */}
        <div className="animate-fade-up-4 grid grid-cols-3 gap-6 max-w-2xl mx-auto mb-24">
          {[
            { value: '< 30s', label: 'Analysis time' },
            { value: '95%', label: 'Accuracy rate' },
            { value: '4 formats', label: 'PDF, DXF, DWG, Image' },
          ].map((s) => (
            <div key={s.label} className="rounded-2xl p-4 border"
              style={{ background: 'var(--bg-elevated)', borderColor: 'var(--border)' }}>
              <p className="text-2xl font-black mb-1" style={{ fontFamily: 'var(--font-display)', color: 'var(--accent)' }}>{s.value}</p>
              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{s.label}</p>
            </div>
          ))}
        </div>

        {/* Feature cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 max-w-5xl mx-auto">
          {[
            {
              icon: '📐',
              title: 'Intelligent Room Detection',
              desc: 'Gemini Vision AI reads room labels, dimensions, and spatial relationships from any blueprint format.',
              tag: 'Vision AI',
            },
            {
              icon: '📊',
              title: 'Accurate BOQ Generation',
              desc: 'Generates itemised Bill of Quantities — bricks, cement, steel, tiles — with Indian market rates.',
              tag: 'BOQ Engine',
            },
            {
              icon: '🏢',
              title: 'Individual & Organisation',
              desc: 'Personal dashboards for engineers. Shared team dashboards for construction firms.',
              tag: 'Multi-tenant',
            },
          ].map((f) => (
            <div key={f.title}
              className="group rounded-2xl p-6 border text-left transition-all duration-300 cursor-default"
              style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = 'var(--border-bright)';
                e.currentTarget.style.background = 'var(--bg-elevated)';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = 'var(--border)';
                e.currentTarget.style.background = 'var(--bg-card)';
              }}>
              <div className="text-3xl mb-4">{f.icon}</div>
              <div className="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-mono mb-3"
                style={{ background: 'var(--accent-glow)', color: 'var(--accent)' }}>
                {f.tag}
              </div>
              <h3 className="text-base font-bold mb-2" style={{ fontFamily: 'var(--font-display)', color: 'var(--text-primary)' }}>{f.title}</h3>
              <p className="text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t py-8 text-center text-sm"
        style={{ borderColor: 'var(--border)', color: 'var(--text-muted)' }}>
        © 2025 BlueprintAI · Built for architects and engineers
      </footer>
    </main>
  );
}