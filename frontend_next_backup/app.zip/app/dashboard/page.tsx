import Navbar from "@/components/Navbar";
import BlueprintAnalyzer from "@/components/BlueprintAnalyzer";
import { currentUser } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";

export default async function DashboardPage() {
  const user = await currentUser();
  if (!user) redirect("/sign-in");

  return (
    <div className="min-h-screen" style={{ background: 'var(--bg-base)' }}>
      <Navbar />
      <div className="max-w-7xl mx-auto px-6 pt-8 pb-4">
        <div className="animate-fade-up">
          <p className="text-xs font-mono mb-1" style={{ color: 'var(--text-muted)' }}>
            Personal Workspace
          </p>
          <h1 className="text-4xl font-black tracking-tight" style={{ fontFamily: 'var(--font-display)', color: 'var(--text-primary)' }}>
            My Dashboard
          </h1>
          <p className="mt-2 text-sm" style={{ color: 'var(--text-secondary)' }}>
            Welcome back, {user.firstName ?? user.emailAddresses[0]?.emailAddress}.
            Your analyses are private to you.
          </p>
        </div>
      </div>
      <BlueprintAnalyzer isOrg={false} />
    </div>
  );
}