import Navbar from "@/components/Navbar";
import BlueprintAnalyzer from "@/components/BlueprintAnalyzer";
import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";

export default async function OrgDashboardPage() {
  const { userId, orgId } = await auth();
  if (!userId) redirect("/sign-in");
  if (!orgId) redirect("/dashboard");

  return (
    <div className="min-h-screen" style={{ background: 'var(--bg-base)' }}>
      <Navbar />
      <div className="max-w-7xl mx-auto px-6 pt-8 pb-4">
        <div className="animate-fade-up">
          <p className="text-xs font-mono mb-1" style={{ color: 'var(--text-muted)' }}>
            Organisation Workspace
          </p>
          <h1 className="text-4xl font-black tracking-tight" style={{ fontFamily: 'var(--font-display)', color: 'var(--text-primary)' }}>
            Team Dashboard
          </h1>
          <p className="mt-2 text-sm" style={{ color: 'var(--text-secondary)' }}>
            Blueprints uploaded here are shared with all members of your organisation.
          </p>
        </div>
      </div>
      <BlueprintAnalyzer isOrg={true} />
    </div>
  );
}